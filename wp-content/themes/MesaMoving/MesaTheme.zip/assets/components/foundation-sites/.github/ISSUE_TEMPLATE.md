<!-- Please only file bugs with Foundation on GitHub. If you've got a more general question about how to use Foundation, we can help you on the Foundation Forum: http://foundation.zurb.com/forum -->

**How can we reproduce this bug?**

1. Step one
2. Step two
3. Step three

**What did you expect to happen?**

**What happened instead?**

**Test case:**

Give us a link to a CodePen or JSFiddle that recreates the issue.

- [CodePen with Foundation 6 and MotionUI](http://codepen.io/rafibomb/pen/xVVGOB)
- [CodePen with Foundation 6, Flexbox grid and MotionUI](http://codepen.io/rafibomb/pen/jqqPra)
