<?php
    // Mesa default CTA
?>

<section class="call-to-action">
    <div class="row text-center">
        <div class="small-12 columns">
            <p>Discover how much easier a little help <br />from our experts can make your move.</p>
            <a href="/contact" class="button button-yellow">Get A Free Quote!</a>
        </div>
    </div>
</section>
